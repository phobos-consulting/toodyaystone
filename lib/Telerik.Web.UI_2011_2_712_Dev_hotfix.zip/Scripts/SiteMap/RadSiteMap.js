(function(){Type.registerNamespace("Telerik.Web.UI");
var a=Telerik.Web.UI;
a.RadSiteMap=function(b){a.RadSiteMap.initializeBase(this,[b]);
};
a.RadSiteMap.prototype={initialize:function(){a.RadSiteMap.callBaseMethod(this,"initialize");
},dispose:function(){a.RadSiteMap.callBaseMethod(this,"dispose");
},get_clientStateFieldID:function(){},set_clientStateFieldID:function(b){}};
a.RadSiteMap.registerClass("Telerik.Web.UI.RadSiteMap",Sys.UI.Control);
})();
