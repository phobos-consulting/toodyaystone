Type.registerNamespace("Telerik.Web.UI");
Telerik.Web.RadDatePickerPopupDirection=function(){throw Error.invalidOperation();
};
Telerik.Web.RadDatePickerPopupDirection.prototype={TopLeft:11,TopRight:12,BottomLeft:21,BottomRight:22};
Telerik.Web.RadDatePickerPopupDirection.registerEnum("Telerik.Web.RadDatePickerPopupDirection");
